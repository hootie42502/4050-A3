#ifndef _Util_h
#define _Util_h

#ifdef __cplusplus
extern "C" 
{
#endif

// Put prototypes and such here for your utility functions

#ifdef __cplusplus
}
#endif

#endif
